import React from 'react'

export default function Help() {
  return (
    <div>
      <h2>Hi im fggg</h2>
    </div>
  )
}
