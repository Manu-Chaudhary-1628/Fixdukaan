import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons';
import React,{useState} from 'react'
import { Link } from 'react-router-dom'
import './Body.css'
import Moreproducts from './Moreproducts'


export default function Body() {
    
    return (
    <div>
    <div>
            <script src="sdc.js"></script>
    <img className="image2" src={require("./images/co.jpg")} alt="Fix Dukaan"/>
</div>

<div className="bovy">
<div className="wrapperh">
    <div className="static-txt">Get Your</div>
    <ul className="dynamic-txts">
        <li><span>"Kettle"</span></li>
        <li><span>"Room Heater"</span></li>
        <li><span>"Geyser"</span></li>
        <li><span>"Induction"</span></li>
        <li><span>"Hair Dryer"</span></li>
        <li><span>"Extension Board"</span></li>
        <li><span>"Iron"</span></li>
        <li><span>"Fan"</span></li>
        <li><span>"Lights"</span></li>
        <li><span>"Ac"</span></li>
        <li><span>"Cooler"</span></li>
        <li><span>"Refrigerator"</span></li>
        <li><span>"Washing Machine"</span></li>
        <li><span>"Switch Board"</span></li>
        <li><span>"Mixer Grinder"</span></li>

    </ul>
    <div className="static-txt">Fixed</div>
</div>
</div>

<hr/>


<div className="wrapper">
    <div className="search-input">
      
        <input type="text" placeholder="Search For Products..."/>
        <div className="autocom-box">
            <li>Kettle</li>
            <li>Hair Dryer</li>
            <li>Extension Board</li>
            <li>Iron</li>
            <li>Induction</li>
            <li>Room Heater</li>
            <li>Geyser</li>
            <li>Fan</li>
            <li>Light</li>
            <li>Ac</li>
            <li>Cooler</li>
            <li>Washing Machine</li>
            <li>Refrigerator</li>
            <li>Switch Board</li>
            <li>Mixer Grinder</li>
            <li>Microwave</li>
            <li>Oven</li>
        </div>
        <FontAwesomeIcon className="icon2" icon={faMagnifyingGlass} />
    </div>
</div>
<script src="js/suggestions.js"></script>
<script src="js/script.js"></script>
<hr/>

<div className='products' >
    
<div class=" perspective-left">
        <div class=" perspective-right">
<div className="imgclass"><Link  to="/Kettle"><img src={require("./images/kettle.jpg")} className="fk"  alt="Kettle" width="130px" height="130px" to=""/>Kettle</Link></div>
        </div>
      </div>

  <div class=" perspective-left">
    <div class=" perspective-right">
        <div className="imgclass"><Link  to="/Dryer"><img src={require("./images/dryer.jpg")} className="fk"  alt="Hair Dryer" width="130px" height="130px" to=""/>Hair Dryer</Link></div>
     </div>
  </div>
     
  <div class=" perspective-left">
    <div class=" perspective-right">
       
    <div className="imgclass"><Link  to="/Extension"><img src={require("./images/kt.jpg")} className="fo"  alt="Extension Board"  width="130px" height="130px"to=""/>Extension Board</Link></div>
     </div>
  </div>
    
  <div class=" perspective-left">
    <div class=" perspective-right">
       
    <div className="imgclass"><Link  to="/Iron"><img src={require("./images/iron.jpg")} className="fx"  alt="Iron" width="130px" height="130px"to="" />Iron</Link></div>
     </div>
  </div>

  <div class=" perspective-left">
    <div class=" perspective-right">
       
    <div className="imgclass"><Link  to="/Induction"><img src={require("./images/indu.jpg")} className="fs"  alt="Induction" width="130px" height="130px"to="" />Induction</Link></div>
     </div>
  </div>
   
  <div class=" perspective-left">
    <div class=" perspective-right">
       
    <div className="imgclass"><Link  to="/Heater"><img src={require("./images/op.jpg")}  className="fn" alt="Room Heater"  width="130px" height="130px"to="" />Room Heater</Link></div>
     </div>
  </div>

  <div class=" perspective-left">
    <div class=" perspective-right">
       
    <div className="imgclass"><Link  to="/Geyser"><img src={require("./images/ff.jpg")} className="fz"  alt="Geyser"width="130px" height="130px" to="" />Geyser</Link></div>
     </div>
  </div>

  <div class=" perspective-left">
    <div class=" perspective-right">
       
    <div className="imgclass"><Link  to="/Fan"><img src={require("./images/jagu.jpg")} className="fm" alt="Fan"width="130px" height="130px" to="" />Fan</Link></div>
     </div>
  </div>
    <i className="fa-sharp fa-solid fa-arrow-right-from-bracket"></i>
   </div>
    <div className='moreproduct'>
   <Link to="/Moreproducts" element = {<Moreproducts/>}>  <b> More Products </b> </Link>
   </div>

</div>
  )
}
