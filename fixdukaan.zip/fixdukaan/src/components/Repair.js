import React from 'react'

export default function Repair() {
  return (
    <div>
        <div className="dropdown-content">
<a href="#" onClick={clickHandler("repairing.html")}>Only Repairing:<b>Rs.100</b></a>
<a href="#" onClick={clickHandler("repairing.html")}>Switch:<b>Rs.100</b></a>
<a href="#" onClick={clickHandler("repairing.html")}>Element:<b>Rs.100</b></a>
<a href="#" onClick={clickHandler("idk.html")}>I Don't Know What Is Causing Problem(Send Your Guy To Repair It)</a>
</div>
      
    </div>
  )
}

