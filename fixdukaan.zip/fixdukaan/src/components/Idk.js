import React from 'react'
import { Link } from 'react-router-dom';
import './Idk.css'


export default function Idk() {
  return (
    <div>
       
<h1>Payment</h1>
    <hr/>
    <h3>We'll send our guy for repairing your product, pay the required amount to him only after you are satisfied with the repairement process.</h3>
    <button  class="button button1">Proceed</button>
    </div>
  )
}
