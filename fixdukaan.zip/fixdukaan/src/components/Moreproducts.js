import React from 'react'
import { Link } from 'react-router-dom'
import './Moreproducts.css'
import Light from './Light'
export default function Moreproducts() {
  return (
    <>
    <h1 className="more">More Products:</h1>
<hr/>

<div className='first2'>

    
<div class=" perspective-left">
        <div class=" perspective-right">
   
   <div ><Link to="/Light" element = {<Light/>}> <img src={require("./images/lamp.jpg")} className="kf" width="130px" height="130px" alt="Lights"  /><h4 className="pink">Lights</h4></Link></div>

        </div>
      </div>

      <div class=" perspective-left">
        <div class=" perspective-right">

   <div ><Link to="/Ac"><img src={require("./images/tytt.jpg")} className="of" width="130px" height="130px" alt="Ac"  /><h4 className="red">Ac</h4></Link></div>
        </div>
      </div>
      <div class=" perspective-left">
        <div class=" perspective-right">

   <div ><Link to="/Cooler"><img src={require("./images/cooler.jpg")} className="xf" width="130px" height="130px" alt="Cooler"  /><h4 className="blue">Cooler</h4></Link></div>
        </div>
      </div>
      <div class=" perspective-left">
        <div class=" perspective-right">

   <div ><Link to="/WashingMachine"><img src={require("./images/machine.jpg")} className="sf" width="130px" height="130px" alt="Washing Machine"  /><h4 className="black">Washing Machine</h4></Link></div>
        </div>
      </div>

      <div class=" perspective-left">
        <div class=" perspective-right">

   <div ><Link to="/SwitchBoard"><img src={require("./images/switch.jpg")} className="nf" width="130px" height="130px" alt="Switch Board"  /><h4 className="hy">Switch Board</h4></Link></div>
        </div>
      </div>

      <div class=" perspective-left">
        <div class=" perspective-right">

   <div ><Link to="/Refrigerator"><img src={require("./images/ref.jpg")} className="zf"  width="130px" height="130px" alt="Refrigerator"  /><h4 className="mus">Refrigerator</h4></Link></div>
        </div>
      </div>

      <div class=" perspective-left">
        <div class=" perspective-right">

   <div ><Link to="/Microwave"><img src={require("./images/oven.jpg")} className="mf" width="130px" height="130px" alt="Microwave"  /><h4 className="yellow">Microwave</h4></Link></div>
        </div>
      </div>

      <div class=" perspective-left">
        <div class=" perspective-right">

   <div ><Link to="/Oven"><img src={require("./images/ovenn.jpg")} className="gf" width="130px" height="130px" alt="Oven"  /><h4 className="grey">Oven</h4></Link></div>
        </div>
      </div>
      <div class=" perspective-left">
        <div class=" perspective-right">

   <div ><Link to="/MixerGrinder"><img src={require("./images/grinder.jpg")} className="pf" width="130px" height="auto" alt="Mixer Grinder"  /><h4 className="brown">Mixer Grinder</h4></Link></div>
        </div>
      </div>

</div>   

  


    </>
  )
}
