import React from 'react'
import { Link } from 'react-router-dom';
import './Extension.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleCheck } from '@fortawesome/free-solid-svg-icons';



export default function Extension() {
  return (
    <div>
       
<h1>Extension Board</h1>
<hr/>
<h2>Related Shops:</h2>
<br/>
<h3>1. Uttranchal Electrical-</h3>
<br/>
<Link  to='/Extuu' ><img src={require("./images/fdgg.jpg")} className="logo" /></Link>
<h3><b>Repairing Amount Rs.100</b></h3>
<br/>
<h4 class="pic">Repairment At Home</h4>
<FontAwesomeIcon className="icon3" icon={faCircleCheck} />
<br/>
<h4 class="pic">Pick-Repair-Drop</h4>
<FontAwesomeIcon className="icon3" icon={faCircleCheck} />
</div>
    
  )
}
