import React,{useState} from 'react'
import { Link } from 'react-router-dom'
import "./Login.css"
import { useForm } from 'react-hook-form';

export default function Login() {
    const { register, handleSubmit, formState: { errors } } = useForm()
    const [state,setState] = useState(1);
    const [name,setname] = useState("Signup");
    const open=()=>{
        if(state == 1){
            setState(2);
            setname("Already have account");
        }
        else{
            setState(1);
            setname("Create an account");
        }
    }
    const onSubmit = data => {
        console.log(data);
    
    };
  return (
    <>
       <button onClick = {open}>{name}</button>
   {state ===1?<div>
        <form id='form' className='flex flex-col' onSubmit={handleSubmit(onSubmit)}>
            <div className="container">
                    <div className="imgcontainer">
                        
                        <img src={require("./images/profile2.png")} alt="Avatar"  className="avatar"/>
                    </div>
                    <hr/>
                        <label><b>Username</b></label>
                        <input type="text" {...register("username",{ required : true })} placeholder='Enter Your Name' />
                        <label><b>Password</b></label>
                        <input type="Password" {...register("password",{ required : true })} placeholder='Enter your password' />
                        {errors.username?.type === "required" && "User Name Required" }
                        {errors.password?.type === "required" && "password Required"}
                        <hr/>
                        <button >Login</button>
            </div>
                    </form>

    </div>:""}
   
{state ===2?<div>
        <form id='form' className='flex flex-col' onSubmit={handleSubmit(onSubmit)}>
        <div className="container">
                <div className="imgcontainer">
                    
                    <img src={require("./images/profile2.png")} alt="Avatar" width="90px" height="90px" className="avatar"/>
                </div>
                <hr/>
                    <label><b>Your Name</b></label>
                    <br/> <input type="text" {...register("username",{ required : true })} placeholder='Enter Your Name' />
                    <br/>
                    <label><b>Your Email</b></label>
                     <br/> <input type="text" {...register("email",{ required : true })} placeholder='Enter Your Email' />
                    <br/>
                    <label><b>Your Number</b></label>
                    <br/><input type="number" {...register("mobile", { required : true, maxLength: 10 })} placeholder='EnterYourMobile Number' />
                    <br/>
                    <label><b> Set your Password</b></label>
                    <br/><input type="Password" {...register("Password",{ required : true })} placeholder='Enter your password' />
                    <br/>
                    <label><b> Re enter your Password</b></label>
                    <br/><input type="Password" {...register("rePassword",{ required : true })} placeholder='Reenter your password' />
                    {errors.username?.type === "required" && "User Name Required" }
                    {errors.email?.type === "required" && "Email Required"}
                    {errors.code?.type === "required" && "Invitation code required"}
                    {errors.mobile?.type === "required" && "Mobile Number is required"}
                    {errors.password?.type === "required" && "password is required"}
                    {errors.mobile?.type === "maxLength" && "Max Length Exceed"}
                    <button className='psw'>Sign up</button>
                    </div>
                </form>
        </div>:""}
       


   
   </>
  )
}

