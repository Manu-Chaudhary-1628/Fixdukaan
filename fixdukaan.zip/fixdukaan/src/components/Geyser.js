import React from 'react'
import { Link } from 'react-router-dom';
import './Geyser.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleCheck } from '@fortawesome/free-solid-svg-icons';

export default function Geyser() {
  return (
    <div>
     
<h1>Geyser</h1>
<hr/>
<h2>Related Shops:</h2>
<br/>
<h3>1. Rawat Telecommunications</h3>
<br/>
<Link  to='/Geyseru' ><img src={require("./images/jh.jpg")} className="logo" /></Link>

<br/>
<h4 class="pic">Repairment At Home</h4>
<FontAwesomeIcon className="icon3" icon={faCircleCheck} />
<br/>
<h4 class="pic">Pick-Repair-Drop</h4>
<FontAwesomeIcon className="icon3" icon={faCircleCheck} />
</div>
   
  )
}
