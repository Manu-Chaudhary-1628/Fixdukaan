import React from 'react'
import { Link } from 'react-router-dom';
import './Kettleu.css'


export default function Kettleu() {
  return (
    <div>
  
      <h1>Uttranchal Electrical</h1>
    <hr/>
    <h3 class="par">Shop Name: <b>Uttranchal Electrical</b></h3>
    <h3 class="par">Shopkeeper Name: <b>Salim</b></h3>
    <h3 class="par">Contact No.: <b>8193921274</b></h3>
   
      <hr/>
      <h3 class="pat">Contact Details:</h3>
      <p>Name: <input type="text" placeholder="Enter your name..." name="name"/></p>
      <p>Mobile no: <input type="tel" placeholder="Enter your Mobile no..." name="phone" id="phone" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}"
        /></p>
      <h3 class="pat">Your Full Address:</h3>
      <p><textarea placeholder="Enter your Address..." name="address" id="address" cols="100" rows="7"></textarea></p>


<h3 class="part">Electric Kettle Parts-</h3>
      <div class="dropdown">
          <button class="dropbtn">Get Your Kettle Fixed</button>
          <div class="dropdown-content">
            <Link to="/Repairing" >Only Repairing:<b>Rs.100</b></Link>
            <Link to="/Switches" >Switch:<b>Rs.150</b></Link>
            <Link to="/Autocut" >Auto Cut:<b>Rs.300</b></Link>
            <Link to="/Idk" >I Don't Know What Is Causing Problem(Send Your Guy To Repair It)</Link>
          </div>
        </div>

    </div>
  )
}
