import React,{useState} from 'react'
import { Link } from 'react-router-dom'
import './Light.css'

export default function Light() {
   
  return (
    <div>
        
    <h1>Lights</h1>
<hr/>

<h2>Related Shops:</h2>
<h3>1. Uttranchal Electrical -</h3>
<div className="ket"  >
<Link  to='/Lightu' ><img src={require("./images/gy.jpg")} className="logo" /></Link>
<h3><b>Repairing Amount Rs.100</b></h3>
<i className="fa-sharp fa-regular fa-circle-check"></i>
<h4 className="pic">Repairment At Home</h4>
<i className="fa-sharp fa-regular fa-circle-check"></i>
<h4 className="pic">Pick-Repair-Drop</h4>
</div>
    </div>
  )
}

