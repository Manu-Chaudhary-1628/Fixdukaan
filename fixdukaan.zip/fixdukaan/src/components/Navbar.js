import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';   
import { faUser } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav>
    <div className="first bg-dark">
    <i className="fa-solid fa-user"></i>
    <Link className="hii" to="/Login" ><b>Login/Signup</b></Link>
    
    <Link className="hii" to="/"><b>Home</b></Link>
    <FontAwesomeIcon className="icon1" icon={faUser} />
    <Link className="hii" to="/Profile"><b> Profile</b></Link>
    
     <div >
        <Link to="/"><div className="word">Fixdukaan</div></Link>
        
      </div> 
</div>

</nav>


  )
}