import React from 'react'
import { Link } from 'react-router-dom'
import './Profile.css'
export default function Profile() {
  return (
    <>
      
    <div className="container">
        <div className="user-image">
        <img src={require("./images/profile.jpg")}  alt="this image contains user-image"/>
        </div>
 
        <div className="content">
             <Link className="name">Your profile</Link>
             <hr/>
                <div> 
                    <Link className="effect effect-4" to="#">
                    Your Order History
                         </Link>
            </div>
            <div>
            <Link className="effect effect-4" to="#" >
                Your Details
            </Link>
    </div>
        <div>
            <Link className="effect effect-4" to="#" >
                LOG OUT
            </Link>
        </div>
    </div>
</div>
     


    </>
  )
}
