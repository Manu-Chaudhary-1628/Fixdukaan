import React from 'react'
import { Link } from 'react-router-dom';
import './Ac.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleCheck } from '@fortawesome/free-solid-svg-icons';

export default function Ac() {
  return (
    <div>
       

       <h1>Ac</h1>
<hr/>
<h2>Related Shops:</h2>
<br/>
<h3>1. Rawat Electricals-</h3>
<br/>
<Link  to='/Acu' ><img src={require("./images/rt.jpg")} className="logo" /></Link>
<h3><b>Repairing Amount Rs.100</b></h3>
<br/>
<h4 class="pic">Repairment At Home</h4>
<FontAwesomeIcon className="icon3" icon={faCircleCheck} />
<br/>
<h4 class="pic">Pick-Repair-Drop</h4>
<FontAwesomeIcon className="icon3" icon={faCircleCheck} />
<br/>
</div>
    
  )
}

