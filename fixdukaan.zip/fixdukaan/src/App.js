import Navbar from './components/Navbar';
import Body from './components/Body';
import Login from './components/Login';
import Home from './components/Home';
import Profile from './components/Profile';
import Moreproducts from './components/Moreproducts';
import Light from './components/Light';
import Lightu from './components/Lightu';
import Shop from './components/Shop'
import Autocut from './components/Autocut';
import Kettle from './components/Kettle';
 import Kettleu from './components/Kettleu';
import Repairing from './components/Repairing';
import Switchu from './components/Switchu';
import Idk from './components/Idk';
import Dryer from './components/Dryer';
import Dryu from './components/Dryu';
import Extension from './components/Extension';
import Extuu from './components/Extuu';
import Iron from './components/Iron';
import Iru from './components/Iru';
import Induction from './components/Induction';
import Indu from './components/Indu';
import Heater from './components/Heater';
import Heatu from './components/Heatu';
import TwoHund from './components/TwoHund';
import Geyser from './components/Geyser';
import Geyseru from './components/Geyseru';
import Fan from './components/Fan';
import Fanu from './components/Fanu';
import Ac from './components/Ac';
import Acu from './components/Acu';
import Cooler from './components/Cooler';
import Coolu from './components/Coolu';
import Refrigerator from './components/Refrigerator';
import Refru from './components/Refru';
import WashingMachine from './components/WashingMachine';
import Washu from './components/Washu';
import SwitchBoard from './components/SwitchBoard';
import Microwave from './components/Microwave';
import Microwaveu from './components/Microwaveu';
import Oven from './components/Oven';
import Ovenu from './components/Ovenu';
import MixerGrinder from './components/MixerGrinder';
import MixerGrinderu from './components/MixerGrinderu';

import {
  BrowserRouter as Router,
  Route,
  Routes,
  Link,
  Switch
} from "react-router-dom";

function App(){
  return  (
    <>

        <Router>
          <Navbar></Navbar>
          
            <Routes>
              <Route path = "/" element = {<Body/>}/>
              <Route path = "/Login" element={<Login/>}/>
              <Route path = "/Profile"element={<Profile/>}/>
              <Route path = "/Home"element={<Home/>}/>
              <Route path = "/Moreproducts"element={<Moreproducts/>}/>
              
              <Route path = "/Light"element={<Light/>}/> 
              <Route path = "/Lightu"element={<Lightu/>}/>

              <Route path = "/Shop"element={<Shop/>}/>    
              
               <Route path = "/Kettle" element={<Kettle/>}/>
              <Route path = "/Kettleu" element={<Kettleu/>}/>
              <Route path = "/Repairing" element={<Repairing/>}/>
              <Route path = "/Switchu" element={<Switchu/>}/>
              <Route path = "/Autocut" element={<Autocut/>}/>
              <Route path = "/Idk" element={<Idk/>}/>

               <Route path = "/Dryer" element={<Dryer/>}/>
               <Route path = "/Dryu" element={<Dryu/>}/>

               <Route path = "/Extension" element={<Extension/>}/>
               <Route path = "/Extuu" element={<Extuu/>}/>

               <Route path = "/Iron" element={<Iron/>}/>
               <Route path = "/Iru" element={<Iru/>}/>
               
               <Route path = "/Induction" element={<Induction/>}/>
               <Route path = "/Indu" element={<Indu/>}/>

               <Route path = "/Heater" element={<Heater/>}/>
               <Route path = "/Heatu" element={<Heatu/>}/>
               <Route path = "/TwoHund" element={<TwoHund/>}/>

               <Route path = "/Geyser" element={<Geyser/>}/>
               <Route path = "/Geyseru" element={<Geyseru/>}/>

               <Route path = "/Fan" element={<Fan/>}/>
               <Route path = "/Fanu" element={<Fanu/>}/>

               <Route path = "/Ac" element={<Ac/>}/>
               <Route path = "/Acu" element={<Acu/>}/>

               <Route path = "/Cooler" element={<Cooler/>}/>
               <Route path = "/Coolu" element={<Coolu/>}/>

               <Route path = "/Refrigerator" element={<Refrigerator/>}/>
               <Route path = "/Refru" element={<Refru/>}/>

               <Route path = "/WashingMachine" element={<WashingMachine/>}/>
               <Route path = "/Washu" element={<Washu/>}/>

               <Route path = "/SwitchBoard" element={<SwitchBoard/>}/>

               <Route path = "/Microwave" element={<Microwave/>}/>
               <Route path = "/Microwaveu" element={<Microwaveu/>}/>

               <Route path = "/Oven" element={<Oven/>}/>
               <Route path = "/Ovenu" element={<Ovenu/>}/>

               <Route path = "/MixerGrinder" element={<MixerGrinder/>}/>
               <Route path = "/MixerGrinderu" element={<MixerGrinderu/>}/>
            </Routes>
        </Router>
        
     </>
  )
}
export default App;
